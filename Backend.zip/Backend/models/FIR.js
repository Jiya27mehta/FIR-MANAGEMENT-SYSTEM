const mongoose = require("mongoose");
const FIRSchema = new mongoose.Schema({
  user_id: String,
  fir_type: String,
  description: String,
  location: String,
  date_filed: { type: Date, default: Date.now },
  status: { type: String, default: "Pending" },
  priority: { type: Number, default: 3 },
});
module.exports = mongoose.model("FIR", FIRSchema);
