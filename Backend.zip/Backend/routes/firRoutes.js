const express = require("express");
const router = express.Router();
const FIR = require("../models/FIR");

function assignPriority(fir_type, description) {
  const critical_keywords = ["fraud", "cybercrime", "financial scam", "hacking", "extortion", "terror"];
  fir_type = fir_type.toLowerCase();
  description = description.toLowerCase();

  if (["cybercrime", "terrorism", "murder"].includes(fir_type)) return 1;
  if (critical_keywords.some(word => description.includes(word))) return 1;
  if (["theft", "harassment", "missing"].includes(fir_type)) return 2;
  return 3;
}

router.post("/register_fir", async (req, res) => {
  try {
    const { user_id, fir_type, description, location } = req.body;
    const priority = assignPriority(fir_type, description);
    const fir = new FIR({ user_id, fir_type, description, location, priority });
    await fir.save();
    res.json({ message: "FIR registered", priority, id: fir._id });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.get("/user_firs/:user_id", async (req, res) => {
  try {
    const firs = await FIR.find({ user_id: req.params.user_id });
    res.json(firs);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;