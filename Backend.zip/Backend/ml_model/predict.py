import sys

# Enhanced mock model for better testing
# Now supports more keywords and is easier to trigger different priorities

def predict_priority(description):
    desc = description.lower()
    # Priority 1: Most critical
    if any(word in desc for word in [
        "terror", "murder", "fraud", "bomb", "attack", "explosion", "kidnap", "hostage", "shooting", "gun", "threat"
    ]):
        return 1
    # Priority 2: Medium
    elif any(word in desc for word in [
        "harassment", "theft", "robbery", "assault", "burglary", "fight", "violence", "abuse"
    ]):
        return 2
    # Priority 3: Low/Other
    else:
        return 3

if __name__ == "__main__":
    input_desc = " ".join(sys.argv[1:])
    print(predict_priority(input_desc))
